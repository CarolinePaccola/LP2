﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Form1 : Form
    {
        double[,] vendas = new double[4, 4];
        double totGeral = 0, totMes = 0, venda = 0;
        string auxiliar;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxVendas.Items.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox($"Mês {i + 1} - Semana {j + 1}", "Entrada Dados");
                    if (!Double.TryParse(auxiliar, out venda) || venda < 0)
                    {
                        MessageBox.Show("Digite um valor válido");
                        j--;
                    }
                    else
                    {
                        vendas[i, j] = venda;
                        totGeral += venda;
                    }
                }
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            for (int i = 0;i < 4;i++)
            {
                string saida = "";
                totMes = 0;

                for (int j = 0;j < 4;j++)
                {
                    saida += $"Total Mês: {i + 1} ";
                    saida += $"Semana {j+1}: {vendas[i, j].ToString("N2")}";
                    saida += "\n";
                    totMes += vendas[i, j];
                    lstbxVendas.Items.Add(saida);
                    saida = "";
                }
                saida = $"Total do Mês: R${totMes.ToString("N2")}\n";
                lstbxVendas.Items.Add(saida);
                saida = "--------------------------------------------";
                lstbxVendas.Items.Add(saida);
            }

            lstbxVendas.Items.Add($"Total Geral : R${totGeral.ToString("N2")}");
            
        }
    }
}
